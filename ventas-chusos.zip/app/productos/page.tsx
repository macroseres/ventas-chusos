import { revalidatePath } from "next/cache";
import Link from "next/link";
import { supabase } from "@/lib/supabase";

async function crearProducto(formData: FormData) {
  "use server";

  const categoria_id = String(formData.get("categoria_id") || "");
  const marca_id = String(formData.get("marca_id") || "");
  const nombre = String(formData.get("nombre") || "").trim();
  const descripcion = String(formData.get("descripcion") || "").trim();

  if (!categoria_id || !marca_id || !nombre) {
    throw new Error("Faltan datos obligatorios.");
  }

  const { data: producto, error: productoError } = await supabase
    .from("productos")
    .insert({
      categoria_id,
      marca_id,
      nombre,
      descripcion,
    })
    .select()
    .single();

  if (productoError) {
    throw new Error(productoError.message);
  }

  const variantes = [];

  for (let i = 1; i <= 10; i++) {
    const talla = String(formData.get(`talla_${i}`) || "").trim();
    const color = String(formData.get(`color_${i}`) || "Sin color").trim() || "Sin color";
    const stock = Number(formData.get(`stock_${i}`) || 0);

    if (talla) {
      const colorLimpio = color.toLowerCase().replaceAll(" ", "-");
      const tallaLimpia = talla.toLowerCase().replaceAll(" ", "-");

      variantes.push({
        producto_id: producto.id,
        color,
        talla,
        codigo: `${producto.id.slice(0, 8)}-${i}-${colorLimpio}-${tallaLimpia}`,
        stock_inicial: stock,
      });
    }
  }

  if (variantes.length === 0) {
    throw new Error("Debes registrar al menos una talla.");
  }

  const variantesParaInsertar = variantes.map(({ stock_inicial, ...variante }) => variante);

  const { data: variantesCreadas, error: variantesError } = await supabase
    .from("variantes")
    .insert(variantesParaInsertar)
    .select();

  if (variantesError) {
    throw new Error(variantesError.message);
  }

  const { data: almacen } = await supabase
    .from("sedes")
    .select("id")
    .eq("tipo", "almacen")
    .limit(1)
    .single();

  if (almacen && variantesCreadas) {
    const inventario = variantesCreadas.map((v, index) => ({
      sede_id: almacen.id,
      variante_id: v.id,
      cantidad: variantes[index].stock_inicial,
      stock_minimo: 0,
    }));

    const { error: inventarioError } = await supabase
      .from("inventario")
      .insert(inventario);

    if (inventarioError) {
      throw new Error(inventarioError.message);
    }
  }

  revalidatePath("/productos");
}

export default async function ProductosPage() {
  const { data: productos } = await supabase
    .from("productos")
    .select(`
      id,
      nombre,
      descripcion,
      activo,
      categorias(nombre),
      marcas(nombre),
      variantes(id)
    `)
    .order("created_at", { ascending: false });

  const { data: categorias } = await supabase
    .from("categorias")
    .select("id, nombre")
    .order("nombre");

  const { data: marcas } = await supabase
    .from("marcas")
    .select("id, nombre")
    .order("nombre");

  return (
    <main className="min-h-screen bg-slate-100 p-4 text-slate-900 md:p-6">
      <section className="mx-auto max-w-6xl">
        <div className="mb-5 flex items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold md:text-3xl">Productos</h1>
            <p className="text-sm text-slate-600 md:text-base">
              Registro rápido para celular: producto, talla, color y stock.
            </p>
          </div>

          <Link
            href="/"
            className="rounded-lg bg-white px-3 py-2 text-sm font-semibold shadow"
          >
            Inicio
          </Link>
        </div>

        <form action={crearProducto} className="mb-6 rounded-xl bg-white p-4 shadow md:p-5">
          <h2 className="mb-4 text-lg font-semibold md:text-xl">Nuevo Producto</h2>

          <div className="grid gap-4 md:grid-cols-2">
            <label className="flex flex-col gap-1">
              <span className="text-sm font-medium">Categoría</span>
              <select name="categoria_id" required className="min-h-11 rounded-lg border p-2 text-base">
                <option value="">Seleccionar categoría</option>
                {categorias?.map((categoria) => (
                  <option key={categoria.id} value={categoria.id}>
                    {categoria.nombre}
                  </option>
                ))}
              </select>
            </label>

            <label className="flex flex-col gap-1">
              <span className="text-sm font-medium">Marca</span>
              <select name="marca_id" required className="min-h-11 rounded-lg border p-2 text-base">
                <option value="">Seleccionar marca</option>
                {marcas?.map((marca) => (
                  <option key={marca.id} value={marca.id}>
                    {marca.nombre}
                  </option>
                ))}
              </select>
            </label>

            <label className="flex flex-col gap-1 md:col-span-2">
              <span className="text-sm font-medium">Nombre del producto</span>
              <input
                name="nombre"
                required
                placeholder="Ejemplo: Escolar Negro"
                className="min-h-11 rounded-lg border p-2 text-base"
              />
            </label>

            <label className="flex flex-col gap-1 md:col-span-2">
              <span className="text-sm font-medium">Descripción</span>
              <textarea
                name="descripcion"
                placeholder="Detalles opcionales"
                className="rounded-lg border p-2 text-base"
              />
            </label>
          </div>

          <div className="mt-6">
            <h3 className="mb-1 text-lg font-semibold">Tallas y stock</h3>
            <p className="mb-4 text-sm text-slate-600">
              Llena solo las filas necesarias. Cada fila representa una talla/color.
            </p>

            <div className="grid gap-3">
              {Array.from({ length: 10 }, (_, i) => {
                const n = i + 1;
                return (
                  <div key={n} className="rounded-xl border bg-slate-50 p-3">
                    <div className="mb-2 text-sm font-semibold text-slate-600">
                      Variante {n}
                    </div>

                    <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
                      <label className="flex flex-col gap-1">
                        <span className="text-xs font-medium">Talla</span>
                        <input
                          name={`talla_${n}`}
                          placeholder="38"
                          className="min-h-11 rounded-lg border p-2 text-base"
                        />
                      </label>

                      <label className="flex flex-col gap-1">
                        <span className="text-xs font-medium">Color</span>
                        <input
                          name={`color_${n}`}
                          placeholder="Negro"
                          defaultValue="Sin color"
                          className="min-h-11 rounded-lg border p-2 text-base"
                        />
                      </label>

                      <label className="col-span-2 flex flex-col gap-1 md:col-span-1">
                        <span className="text-xs font-medium">Stock inicial</span>
                        <input
                          name={`stock_${n}`}
                          type="number"
                          min="0"
                          defaultValue="0"
                          className="min-h-11 rounded-lg border p-2 text-base"
                        />
                      </label>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <button className="mt-5 w-full rounded-lg bg-slate-900 px-4 py-3 text-base font-semibold text-white hover:bg-slate-700 md:w-auto">
            Guardar Producto
          </button>
        </form>

        <div className="mb-3">
          <h2 className="text-lg font-semibold">Productos registrados</h2>
        </div>

        <div className="grid gap-3 md:hidden">
          {productos && productos.length > 0 ? (
            productos.map((producto: any) => (
              <div key={producto.id} className="rounded-xl bg-white p-4 shadow">
                <div className="text-lg font-semibold">{producto.nombre}</div>
                <div className="mt-1 text-sm text-slate-600">
                  {producto.categorias?.nombre || "-"} · {producto.marcas?.nombre || "-"}
                </div>
                <div className="mt-3 flex justify-between text-sm">
                  <span>Variantes: {producto.variantes?.length || 0}</span>
                  <span>{producto.activo ? "Activo" : "Inactivo"}</span>
                </div>
              </div>
            ))
          ) : (
            <div className="rounded-xl bg-white p-4 text-slate-500 shadow">
              No hay productos registrados.
            </div>
          )}
        </div>

        <div className="hidden overflow-hidden rounded-xl bg-white shadow md:block">
          <table className="w-full border-collapse text-left">
            <thead className="bg-slate-900 text-white">
              <tr>
                <th className="p-3">Categoría</th>
                <th className="p-3">Marca</th>
                <th className="p-3">Nombre</th>
                <th className="p-3">Variantes</th>
                <th className="p-3">Estado</th>
              </tr>
            </thead>
            <tbody>
              {productos && productos.length > 0 ? (
                productos.map((producto: any) => (
                  <tr key={producto.id} className="border-b">
                    <td className="p-3">{producto.categorias?.nombre || "-"}</td>
                    <td className="p-3">{producto.marcas?.nombre || "-"}</td>
                    <td className="p-3 font-medium">{producto.nombre}</td>
                    <td className="p-3">{producto.variantes?.length || 0}</td>
                    <td className="p-3">
                      {producto.activo ? "Activo" : "Inactivo"}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td className="p-4 text-slate-500" colSpan={5}>
                    No hay productos registrados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </main>
  );
}
